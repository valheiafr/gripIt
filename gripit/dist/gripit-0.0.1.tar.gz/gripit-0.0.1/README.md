# gripIt
Projet de recherche HES-SO
